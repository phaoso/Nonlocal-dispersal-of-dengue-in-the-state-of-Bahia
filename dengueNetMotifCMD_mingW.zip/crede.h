#ifndef CREDE_H
#define CREDE_H
#include <fstream>
#include <vector>
#include <math.h>
#include <string>
#include <iostream>
#include <QString>
#include <algorithm>
#include "cno.h"


using namespace std;

struct Hstc {
  double sl,sd,r,l,eb;
  int n;
};
class janela;
class cRede
{
private:

    int eletX_pxx;
    int eletX_pxy;
    int eletY_pxy;
    int eletX_pxyy;
    int eletY_pxyy;

    double lag;
    int dmin;
    int dmax;

    vector <int> fMotif1;
    vector <int> fMotif2;
    vector <int> fMotif3;
    vector <int> fMotif4;
    vector <int> fMotif5;
    vector <int> fMotif6;
    vector <int> fMotif7;

    int Matfxy[7][7];
    int Matfxx[7][7];
    int Matfxyy[7][7][7];

    vector <double> VE;
    vector <char> Vmotif;

    vector < vector <double> > ME;
    vector < vector <double> > matPearson;
    vector < vector <char> > matMotifs;
    vector <vector < vector <double> > > MEdelta;
    vector <vector < vector <int> > > MEdeltaMotifs;
    double Px [7];
    double Pxy[7][7];
    double Pxx[7][7];
    double Pxyy[7][7][7];
    vector <string> listaArquivos;        
    struct Hstc Fitting(vector<double> *xa,vector<double> *ya);

public:
    cRede();
    int n_ar(int j);
    double CAv(int i);
    int Vizinho(vector < vector <double> >  dados,int k,int i);

    double media(vector < vector <double> > dados,int j);
    double cov(vector < vector <double> > dados,int j,int k);
    double var(vector < vector <double> > dados,int j);

    double coord31elet[32][2];
    vector < vector <double> > coordelet;
    double thresold;
    double tamanhojan;
    int delta;
    double vInicio;
    int K;
    double h;
    double getPearson(int i,int j);
    char getMotif(int i, int j);
    double getMotifs_size() { return this->matMotifs[0].size();}
    double getME_size() { return this->ME[0].size();}
    double getAdj(int i,int j);
    double getViz(int i,int j);
    double getmDxy(int i,int j);
    double getME(int i,int j){return this->ME[i][j];}
    double getGrauMedio();
    double getCaMedio();
    double getCmMedio();
    double p(int x, int motif);
    double p_conj(int x, int y, int motif_x, int motif_y);
    double p_xx(int x,int delta,int motif1, int motif2);
    double p_xyy(int x, int y, int motif_x, int motif_y, int motif_yd, int delta);
    double Ixy (int x, int y, int delta);
    double Dxy (int x,int y, int d_min, int d_max);
    int getG(int i);
    int getNumDeEnt();

    void calcdirec(int lag, int dmax, int dmin, int tjan, janela *jan, int tfinal, int tinicial);//pcmi com tvg(s� Dxy)
    void calc_tudo9(double thres, int tjan, int lag, int tau, int tfinal, int tinicial, double minV, bool shuffled, bool printLog);//e.synch com tvg e motifs

	void direc_test(double thres, int tjan, int lag, int tau,int K, double h, janela *jan, int tfinal, int tinicial);
    int countA;
    int countD;
    void loadASCII(QString nome_arq);
    void carregaListaAquivos(vector <QString> arquivos);
    void carrega_arq(); //carrega uma lista de arquivos ( para quando os sinais est�o em arquivos separados)
    void carrega_arq2(string nome_arq); //carrega apenas um arquivo q contem tds os sinais
    void shufData();
    void soma_matriz(vector < vector <double> > *m1,vector < vector <double> > *m2);
    void soma_matriz2(vector<vector<double> > m1,vector<vector<double> > m2);
    void gera_motifs();
    void zera();
    double get_posX(int i) {return this->nos[i]->posX;}
    double get_posY(int i) {return this->nos[i]->posY;}
    void set_posX(int i,double value) {this->nos[i]->posX=value;}
    void set_posY(int i,double value) {this->nos[i]->posY=value;}
    int get_no(int i){return this->nos[i]->num;}
    vector <cNo *> nos;
    vector < vector <double> > matDxy;
    vector < vector <double> > matQxy;
    vector < vector <double> > MAdj;
    vector < vector <double> > matDig;
    vector < vector <double> > matrizC;     // REA
    vector < vector <double> > matTau;      // REA Tau Médio
    vector < vector <double> > matrizCD;    // REA Direcional
    vector <vector < vector <int> > > matTvg; // the real TVG G(Node_i,Node_j,time)


    double grauMedio;
    double grauMedioIn;
    double grauMedioOut;
    vector <double> G;
    vector <double> Gin;
    vector <double> Gout;
    double caMedio;
    double cmMedio;
    double tamanho;
    vector < vector <double> > MViz;
    double dpG;
    QString fileName;


    //valores TVG

    vector <vector < vector <double> > > matDxy_tvg;
    vector <vector < vector <double> > > MAdj_tvg;
    vector <vector < vector <double> > > MViz_tvg;
    vector <vector < vector <double> > > matDig_tvg;
    vector <vector < vector <double> > > matQxy_tvg;
    vector <double> grauMedio_tvg;
    vector <double> grauMedioIn_tvg;
    vector <double> grauMedioOut_tvg;
    vector <double> tauMed_tvg;
    vector <double> caMedio_tvg;
    vector <double> cmMedio_tvg;
    vector <vector <double> > G_tvg;
    vector <vector <double> > Gin_tvg;
    vector <vector <double> > Gout_tvg;
    vector <double> arestas_tvg;
    vector <double> Narestas_tvg;
    vector <double> dpG_tvg;
    vector <double> dpGin_tvg;
    vector <double> dpGout_tvg;

    //event synchronization

    void gera_events();
    double tau_ij(int x, int y, int i, int j);
    double tau;
    double Q_xy(int x, int y);
    double q_xy(int x, int y);
    double c_xy(int x, int y);
    double Q2_xy(int x, int y);//com motifs
    double q2_xy(int x, int y);//com motifs
    int c2_xy(int x, int y);//com motifs
    int c2_yx(int x, int y);//com motifs
    void gera_motifs2(); //s� com 5 motifs
    double Jxy,Jyx;
    vector < vector <double> > matEvents;

    double max_arest;




};

#endif // CREDE_H
