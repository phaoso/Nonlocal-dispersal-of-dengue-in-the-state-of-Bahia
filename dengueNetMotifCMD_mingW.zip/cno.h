#ifndef CNO_H
#define CNO_H
#include <string>
#include <cstdlib>
#include <vector>

using namespace std;

class cNo
{
public:
    cNo(string id,int i);
    string id;
    int num;
    double posX;
    double posY;

};

#endif // CNO_H
