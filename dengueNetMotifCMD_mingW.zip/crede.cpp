#include "crede.h"
#include <iostream>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <qdebug.h>
#include <QStringList>

using namespace std;


cRede::cRede()
{
    this->zera();
}

// Calculos das redes



void cRede::calcdirec(int lag, int dmax, int dmin, int tjan, janela *jan, int tfinal, int tinicial)
{
    int num=this->getNumDeEnt();

    this->tamanhojan=tjan;
    this->lag=lag;
    this->dmax=dmax;
    this->dmin=dmin;
    this->delta=dmax;
    this->gera_motifs();


    int sizem=tfinal;

    vector <double> vetnum;

    vetnum.assign(num,0);
    this->matDxy.assign(num,vetnum);

    for(this->vInicio=tinicial;this->vInicio<(sizem-(this->tamanhojan + this->delta + (lag*2+1)));this->vInicio+=1)
    {

        for(int i=0;i<num;i++)
        {
            for(int j=0;j<num;j++)
            {
                this->matDxy[i][j]=0;
            }
        }

        //Indice de dire��o (Matriz)

        for(int i=0;i<num;i++)
        {
            for(int j=0;j<num;j++)
            {
                if(i==j)
                    this->matDxy[i][j]=0;
                else if(i>j)
                    this->matDxy[i][j]=(this->matDxy[j][i])*(-1);
                else
                    this->matDxy[i][j]=Dxy(i,j,dmin,dmax);
            }
        }

        //guarda valores de cada rede_tvg

        this->matDxy_tvg.push_back(this->matDxy);
    }
}



void cRede::calc_tudo9(double thres, int tjan, int lag, int tau, int tfinal, int tinicial,double minV,bool shuffled,bool printLog)
{

    this->zera();
    this->tau=tau;
    this->thresold=thres;
    this->lag=lag;

    int sizem=tfinal;
    this->tamanhojan=tjan;
    int tamTotal= (sizem -(this->tamanhojan+tau)-tinicial);

    int num=getNumDeEnt();
    double Gmedio,GmedioIn,GmedioOut;
    double G2medio,G2,G2medioIn,G2in,G2medioOut,G2out;
    int narest;
	ofstream corr;	

    vector <double> vetnum;
    vector <int> vetInt;
    vector < vector <int> > matnum;
    vetnum.assign(num,0);
    matnum.assign(num,vetInt);
    this->G.assign(num,0);
    this->Gin.assign(num,0);
    this->Gout.assign(num,0);
    this->matDxy.assign(num,vetnum);
    this->matQxy.assign(num,vetnum);
    this->MAdj.assign(num,vetnum);
    this->matDig.assign(num,vetnum);
    this->matTvg.assign(num,matnum);
    this->matrizC.assign(num,vetnum);     // REA
    this->matrizCD.assign(num,vetnum);    //  REA Direcional
    this->matTau.assign(num,vetnum);    //  REA Taus medios

    this->arestas_tvg.assign(tamTotal,0);
    this->Narestas_tvg.assign(tamTotal,0);;
    this->G_tvg.assign(tamTotal,this->G);
    this->Gin_tvg.assign(tamTotal,this->Gin);
    this->Gout_tvg.assign(tamTotal,this->Gout);
    this->grauMedio_tvg.assign(tamTotal,0);
    this->tauMed_tvg.assign(tamTotal,0);
    this->grauMedioIn_tvg.assign(tamTotal,0);
    this->grauMedioOut_tvg.assign(tamTotal,0);
    this->caMedio_tvg.assign(tamTotal,0);
    this->dpG_tvg.assign(tamTotal,0); //desvio padr�o dos graus rede i
    this->dpGin_tvg.assign(tamTotal,0); //desvio padr�o dos graus de entrada da rede i
    this->dpGout_tvg.assign(tamTotal,0); //desvio padr�o dos graus de sa�da da rede i
    if (printLog)
    {
		corr.open("allCorrelations.txt");
        corr << "correlation\ttau\tsource\ttarget"<<endl;
    }

    this->gera_motifs2();
    for(this->vInicio=tinicial;this->vInicio<(sizem -(this->tamanhojan + this->tau));this->vInicio+=1)
    {

        // Matrizes ES (Q e q)
        // Matriz Adjac�ncia
        // Graus da rede
        // Grau medio da rede
        cout << "Calc dia:"<< vInicio << endl;

        Gmedio=0;GmedioIn=0;GmedioOut=0;
        G2=0,G2in=0,G2out=0;
        narest=0;
        this->max_arest=0;
        double tauSum=0;
        int tau_xy,tau_yx;

        for(int i=0;i<num;i++)
        {
            int grau=0,grauIn=0,grauOut=0;

            for(int j=0;j<num;j++)
            {
                if(i==j)
                {
                    this->matQxy[i][j]=0;
                    this->matDxy[i][j]=0;
                    this->MAdj[i][j]=this->matDig[i][j]=0;
                }
                else if(i>j)
                {
                    tau_xy=this->c2_xy(i,j);
                    tau_yx=this->c2_yx(j,i);
                    this->matQxy[i][j]=Q2_xy(i,j);
                    this->max_arest=max(this->matQxy[i][j],this->max_arest);
                    this->matDxy[i][j]=q2_xy(i,j);
					double sumJanX = 0, sumJanY = 0;

					for (int t = this->vInicio; t < (this->vInicio + this->tamanhojan); t++)  // Evluates the sum within the window for nodes i and j
					{
						sumJanX += fabs(this->ME[i][t]); sumJanY += fabs(this->ME[j][t]);
					}
                    if(fabs(this->matQxy[i][j]) <= this->thresold || sumJanX<=minV || sumJanY<=minV)
                        this->MAdj[i][j]=this->matDig[i][j]=this->MAdj[j][i]=0;
                    else if (fabs(this->matQxy[i][j]) > this->thresold)
                    {
                        this->MAdj[i][j]=this->MAdj[j][i]=1;
                        this->matrizC.at(i).at(j)++;
                        this->matrizC.at(j).at(i)++;

                        grau++;
                        narest++;
                        string source=this->nos[i]->id;
                        string target=this->nos[j]->id;
                        if(this->matDxy[i][j]>=0)
                        {
                            tauSum+=tau_xy;
                            grauOut++;
                            this->matrizCD.at(i).at(j)++;
                            this->matTau[i][j]+=tau_xy;
                            if(i==2 && j==0)
                            {
                                cout <<"meleca";
                            }
                            this->matDig[i][j]=1;
                            this->matTvg[i][j].push_back(this->vInicio-tinicial);
                            if (printLog)
                                corr << this->matQxy[i][j] << "\t" << tau_xy << "\t" << source << "\t" << target << endl;
                        }
                        else if(this->matDxy[i][j]<=0)
                        {
                            tauSum+=tau_yx;
                            grauIn++;
                            this->matrizCD.at(j).at(i)++;
                            this->matTau[j][i]+=tau_yx;
                            if(i==2 && j==0)
                            {
                                cout <<"meleca";
                            }
                            this->matDig[j][i]=1;
                            this->matTvg[j][i].push_back(this->vInicio-tinicial);
                            if (printLog)
                                corr << this->matQxy[i][j] << "\t" << tau_yx << "\t" << source << "\t" << target << endl;
                        }
                    }
                }


            }
            this->G[i]=grau;
            this->Gin[i]=grauIn;
            this->Gout[i]=grauOut;
            Gmedio+=this->G[i];
            GmedioIn+=this->Gin[i];
            GmedioOut+=this->Gout[i];
            G2+=this->G[i]*this->G[i];
            G2in+=this->Gin[i]*this->Gin[i];
            G2out+=this->Gout[i]*this->Gout[i];
        }

        grauMedio=Gmedio/num;
        grauMedioIn=GmedioIn/num;
        grauMedioOut=GmedioOut/num;
        G2medio=G2/num;
        G2medioIn=G2in/num;
        G2medioOut=G2out/num;


        //guarda valores de cada rede_tvg
        int t=this->vInicio-tinicial;

        this->arestas_tvg[t]=(this->max_arest);
        this->Narestas_tvg[t]=(narest);
        this->G_tvg[t]=(this->G);
        this->Gin_tvg[t]=this->Gin;
        this->Gout_tvg[t]=(this->Gout);
        this->tauMed_tvg[t]=tauSum/narest;
        this->grauMedio_tvg[t]=(this->grauMedio);
        this->grauMedioIn_tvg[t]=(this->grauMedioIn);
        this->grauMedioOut_tvg[t]=(this->grauMedioOut);
        this->caMedio_tvg[t]=(this->caMedio);
        this->dpG_tvg[t]=(sqrt(G2medio-this->grauMedio*this->grauMedio)); //desvio padr�o dos graus rede i
        this->dpGin_tvg[t]=(sqrt(G2medioIn-this->grauMedioIn*this->grauMedioIn)); //desvio padr�o dos graus de entrada da rede i
        this->dpGout_tvg[t]=(sqrt(G2medioOut-this->grauMedioOut*this->grauMedioOut)); //desvio padr�o dos graus de sa�da da rede i
        // this->MViz_tvg.push_back(this->MViz);
        // this->cmMedio_tvg.push_back(this->cmMedio);
    }
	corr.close();

}


void cRede::direc_test(double thres, int tjan, int lag, int tau,int K, double h, janela *jan, int tfinal, int tinicial)
{
    this->zera();
    this->K=K;
    this->h=h;
    this->thresold=thres;
    this->tau=tau;
    this->lag=lag;

    this->countA=0;
    this->countD=0;

    double idMS,idES;

    int sizem=tfinal;
    this->tamanhojan=tjan;
    int num=getNumDeEnt();

    this->gera_motifs2();

    for(this->vInicio=tinicial;this->vInicio<(sizem-(this->tamanhojan + this->tau));this->vInicio+=1)
    {
        this->gera_events();
        int tau_xy,tau_yx;


        for(int i=0;i<num;i++)
        {
            for(int j=0;j<num;j++)
            {
                if(i<j)
                {
                    tau_xy=this->c2_xy(i,j);
                    tau_yx=this->c2_yx(j,i);
                    if(fabs(this->Q_xy(i,j))>=this->thresold && fabs(this->Q2_xy(i,j)) >= this->thresold)
                    {
                        this->countA++;
                        idMS=this->q2_xy(i,j);
                        idES=this->q_xy(i,j);
                        if((idES>0 && idMS>0) || (idES<0 && idMS<0) || (idES==0 && idMS==0))
                            this->countD++;
                    }
                }
            }
        }
    }
}


//Pearson

struct Hstc cRede::Fitting(vector <double> *xa,vector <double> *ya)
{
    struct Hstc Ht;
    double s,sx=0.0,sy=0.0,sx2=0.0,sxy=0.0,sy2=0.0,a,b,r,rx,ry,w,sa,sb;
    int n=0;
    /*	DETERMINA OS SOMATORIOS	*/
    if(this->tamanhojan!=0)
    {
        for(int i=this->vInicio;i<this->vInicio+this->tamanhojan;i++)
        {
            sx+=xa->at(i);
            sy+=ya->at(i);
            sxy+=xa->at(i)*ya->at(i);
            sx2+=xa->at(i)*xa->at(i);
            sy2+=ya->at(i)*ya->at(i);
            n++;
        }
    }
    else
    {
        for(int i=0;i<xa->size();i++)
        {
            sx+=xa->at(i);
            sy+=ya->at(i);
            sxy+=xa->at(i)*ya->at(i);
            sx2+=xa->at(i)*xa->at(i);
            sy2+=ya->at(i)*ya->at(i);
            n++;
        }
    }

    /*  	CALCULA A INCLINACAO	*/

    /*  calculo dos coeficientes	*/
    s=sx2-sx*sx/n;
    a=(sxy-sx*sy/n)/s;
    b=(sy-a*sx)/n;
    w=sy2+a*a*sx2+n*b*b;
    w=w-2.0*a*sxy-2.0*b*sy+2.0*a*b*sx;
    if (w<0.0) w=0.0;
    else w=sqrt(w/(n-2));
    rx=sx2-sx*sx/n;
    ry=sy2-sy*sy/n;
    // Slope error
    sa=(sy2+n*b*b+a*a*sx2-2*(b*sy-a*b*sx+a*sxy))/(n-1);
    sb=sqrt( (sx2*sa)/(n*sx2-sx*sx) );
    sa=sqrt( (n*sa)/(n*sx2-sx*sx) );

    if(fabs(ry)<1.0e-10)
    {
        if(fabs(a)<1.0e-10) r=1.0;
        else r=30000.0;
    }
    else r=a*a*rx/ry;

    Ht.sl=a;
    Ht.sd=sa;
    Ht.r=sqrt(r);
    Ht.l=b;
    Ht.n=n;
    Ht.eb=sb;
    return Ht;
}

//PCMI

void cRede::gera_motifs()
{
    int cteFinal;
    if(this->dmax<(2*this->lag+1))
    { cteFinal=(2*this->lag+1);}   //Verifica qual vai ser o desconto do final do vetor de entrada, ou pelo tamanho do motif ou pelo delta maximo
    else
    { cteFinal=this->dmax;}

    for(int i=0;i<this->nos.size();i++)
    {
        this->Vmotif.clear();
        int fm1=0,fm2=0,fm3=0,fm4=0,fm5=0,fm6=0,fm7=0;
        for(int j=0;j<(this->ME[i].size()-1)-cteFinal;j++)
        {
            if(this->ME[i][j]>this->ME[i][j+lag] && this->ME[i][j+lag]>this->ME[i][j+2*lag])  // Motif 1
            { this->Vmotif.push_back(1);
                fm1++;}
            else if(this->ME[i][j]>this->ME[i][j+lag] && this->ME[i][j+lag]<this->ME[i][j+2*lag] && this->ME[i][j]>this->ME[i][j+2*lag])  // Motif 2
            { this->Vmotif.push_back(2);
                fm2++;}
            else if(this->ME[i][j]<this->ME[i][j+lag] && this->ME[i][j+lag]>this->ME[i][j+2*lag] && this->ME[i][j]>this->ME[i][j+2*lag])  // Motif 3
            { this->Vmotif.push_back(3);
                fm3++;}
            else if(this->ME[i][j]>this->ME[i][j+lag] && this->ME[i][j+lag]<this->ME[i][j+2*lag] && this->ME[i][j]<this->ME[i][j+2*lag])  // Motif 4
            { this->Vmotif.push_back(4);
                fm4++;}
            else if(this->ME[i][j]<this->ME[i][j+lag] && this->ME[i][j+lag]<this->ME[i][j+2*lag])  // Motif 5
            { this->Vmotif.push_back(5);
                fm5++;}
            else if(this->ME[i][j]<this->ME[i][j+lag] && this->ME[i][j+lag]>this->ME[i][j+2*lag] && this->ME[i][j]<this->ME[i][j+2*lag])  // Motif 6
            { this->Vmotif.push_back(6);
                fm6++;}
            else
            { this->Vmotif.push_back(7);
                fm7++;}
        }
        this->matMotifs.push_back(this->Vmotif);
        this->fMotif1.push_back(fm1);
        this->fMotif2.push_back(fm2);
        this->fMotif3.push_back(fm3);
        this->fMotif4.push_back(fm4);
        this->fMotif5.push_back(fm5);
        this->fMotif6.push_back(fm6);
        this->fMotif7.push_back(fm7);
    }

 }

double cRede::p(int x, int motif)
{
    double P=0;
    if(tamanhojan==0){
        if(motif==1)
            P=this->fMotif1[x]/this->getMotifs_size();
        else if(motif==2)
            P=this->fMotif2[x]/this->getMotifs_size();
        else if(motif==3)
            P=this->fMotif3[x]/this->getMotifs_size();
        else if(motif==4)
            P=this->fMotif4[x]/this->getMotifs_size();
        else if(motif==5)
            P=this->fMotif5[x]/this->getMotifs_size();
        else if(motif==6)
            P=this->fMotif6[x]/this->getMotifs_size();
        else if(motif==7)
            P=this->fMotif7[x]/this->getMotifs_size();
    }
    else //para tvg
    {
        for(int i=0;i<7;i++)
        {
            Px[i]=0;
        }
        double sizem =this->tamanhojan;
        for(int j=this->vInicio;j<(this->vInicio + sizem);j++)
        {
            this->Px[this->matMotifs[x][j]-1]++;
        }
        P=Px[motif-1]/sizem;
    }

    return P;
}

double cRede::p_xx(int x, int delta, int motif1, int motif2)
{
    double sizem;
    int k;
    k=(delta-this->dmin); //d� a localiza��o (k), em MEdeltaMotifs[k][i][j], do vetor delta desejado.
    if(tamanhojan!=0)//para tvg
    {
        sizem =this->tamanhojan;
        if(x!=this->eletX_pxx || x==0)
        {
            this->eletX_pxx=x;

            for(int l=0;l<7;l++)
            {
                for(int n=0;n<7;n++)
                {
                    this->Matfxx[l][n]=0;

                }
            }

            for(int j=this->vInicio;j<((this->vInicio+sizem));j++) //obs: o desconto do delta fica no la�o principal do tvg
            {
                this->Matfxx[this->matMotifs[x][j]-1][this->MEdeltaMotifs[k][x][j]-1]++;
            }

            for(int l=0;l<7;l++)
            {
                for(int n=0;n<7;n++)
                {
                    this->Pxx[l][n]=this->Matfxx[l][n]/(sizem);
                }
            }

        }
    }
    else{
        sizem =this->getMotifs_size();

        if(x!=this->eletX_pxx || x==0)
        {
            this->eletX_pxx=x;

            for(int l=0;l<7;l++)
            {
                for(int n=0;n<7;n++)
                {
                    this->Matfxx[l][n]=0;

                }
            }

            for(int j=0;j<sizem;j++)
            {
                this->Matfxx[this->matMotifs[x][j]-1][this->MEdeltaMotifs[k][x][j]-1]++;
            }

            for(int k=0;k<7;k++)
            {
                for(int n=0;n<7;n++)
                {
                    this->Pxx[k][n]=this->Matfxx[k][n]/sizem;
                }
            }

        }
    }

    return this->Pxx[motif1-1][motif2-1];
}

double cRede::p_conj(int x,int y, int motif_x, int motif_y)
{
    double sizem;

    if(tamanhojan!=0){//para tvg
        sizem =this->tamanhojan;
        if(x!=this->eletX_pxy && y!=this->eletY_pxy || x==0) // verificar par�ntesis aqui GG
        {
            this->eletX_pxy=x;
            this->eletY_pxy=y;
            int f=0;
            double P=0;

            for(int k=0;k<7;k++)
            {
                for(int n=0;n<7;n++)
                {
                    this->Matfxy[k][n]=0;
                }
            }

            for(int j=this->vInicio;j<(this->vInicio+sizem);j++)
            {
                this->Matfxy[this->matMotifs[x][j]-1][this->matMotifs[y][j]-1]++;
                f++;
            }

            for(int k=0;k<7;k++)
            {
                for(int n=0;n<7;n++)
                {
                    this->Pxy[k][n]=this->Matfxy[k][n]/sizem;
                    P+=Pxy[k][n];
                }
            }

        }
    }
    else{
        sizem =this->getMotifs_size();

        if(x!=this->eletX_pxy && y!=this->eletY_pxy || x==0)
        {
            this->eletX_pxy=x;
            this->eletY_pxy=y;

            for(int k=0;k<7;k++)
            {
                for(int n=0;n<7;n++)
                {
                    this->Matfxy[k][n]=0;
                }
            }

            for(int j=0;j<sizem;j++)
            {
                this->Matfxy[this->matMotifs[x][j]-1][this->matMotifs[y][j]-1]++;
            }

            for(int k=0;k<7;k++)
            {
                for(int n=0;n<7;n++)
                {
                    this->Pxy[k][n]=this->Matfxy[k][n]/sizem;
                }
            }

        }
    }

    return this->Pxy[motif_x-1][motif_y-1];
}

double cRede::p_xyy(int x, int y, int motif_x, int motif_y, int motif_yd, int delta)
{
    double sizem;
    int k;
    k=(delta-this->dmin); //d� a localiza��o (k), em MEdeltaMotifs[k][i][j], do vetor delta desejado.

    if(tamanhojan!=0){//para tvg
        sizem =this->tamanhojan;
        if(x!=this->eletX_pxyy && y!=this->eletY_pxyy || x==0)
        {
            this->eletX_pxyy=x;
            this->eletY_pxyy=y;

            for(int k=0;k<7;k++)
            {
                for(int n=0;n<7;n++)
                {
                    for(int m=0;m<7;m++)
                    {
                        this->Matfxyy[k][n][m]=0;
                    }
                }
            }

            for(int j=this->vInicio;j<((this->vInicio+sizem));j++) //obs: o desconto do delta fica no la�o principal do tvg
            {
                this->Matfxyy[this->matMotifs[x][j]-1][this->matMotifs[y][j]-1][this->MEdeltaMotifs[k][x][j]-1]++;
            }

            for(int k=0;k<7;k++)
            {
                for(int n=0;n<7;n++)
                {
                    for(int m=0;m<7;m++)
                    {
                        this->Pxyy[k][n][m]=this->Matfxyy[k][n][m]/sizem;
                    }
                }
            }

        }
    }
    else{
        sizem =this->getMotifs_size();

        if(x!=this->eletX_pxyy && y!=this->eletY_pxyy || x==0)
        {
            this->eletX_pxyy=x;
            this->eletY_pxyy=y;

            for(int l=0;l<7;l++)
            {
                for(int n=0;n<7;n++)
                {
                    for(int m=0;m<7;m++)
                    {
                        this->Matfxyy[l][n][m]=0;
                    }
                }
            }

            for(int j=0;j<sizem;j++)
            {
                this->Matfxyy[this->matMotifs[x][j]-1][this->matMotifs[y][j]-1][this->MEdeltaMotifs[k][x][j]-1]++;
            }

            for(int k=0;k<7;k++)
            {
                for(int n=0;n<7;n++)
                {
                    for(int m=0;m<7;m++)
                    {
                        this->Pxyy[k][n][m]=this->Matfxyy[k][n][m]/sizem;
                    }
                }
            }

        }
    }
    return this->Pxyy[motif_x-1][motif_y-1][motif_yd-1];
}

double cRede::Ixy(int x, int y,int delta)
{
    double Hx_y=0;
    double Hxyy=0;
    double I_xy=0;
    for(int n=1;n<8;n++)
    {
        for(int m=1;m<8;m++)
        {
            if(this->p(y,m)!=0 && this->p_conj(x,y,n,m)!=0)
                Hx_y+=(-1)*(this->p_conj(x,y,n,m)*log(this->p_conj(x,y,n,m)/this->p(y,m)));
        }
    }

    for(int n=1;n<8;n++)
    {
        for(int m=1;m<8;m++)
        {
            for(int k=1;k<8;k++)
            {
                if(this->p_xx(y,delta,m,k)!=0 && this->p_xyy(x,y,n,m,k,delta)!=0)
                    Hxyy+=(-1)*(this->p_xyy(x,y,n,m,k,delta)*log(this->p_xyy(x,y,n,m,k,delta)/this->p_xx(y,delta,m,k)));
            }
        }
    }

    I_xy=Hx_y-Hxyy;

    return I_xy;
}

double cRede::Dxy(int x, int y, int d_min, int d_max)
{
    double I_xy=0,I_yx=0, D_xy=0;
    double sIxy=0,sIyx=0;

    for(int i=0;i<((d_max-d_min)+1);i++)
    {
        sIxy+=Ixy(x,y,d_min+i);
        sIyx+=Ixy(y,x,d_min+i);
    }

    I_xy=sIxy/((d_max-d_min)+1);
    I_yx=sIyx/((d_max-d_min)+1);

    if(I_xy==0 && I_yx==0)
        D_xy=0;
    else
        D_xy=(I_xy-I_yx)/(I_xy+I_yx);


    return D_xy;
}

// Event Synchronization

void cRede::gera_events()
{
    int K=this->K;
    double h=this->h;
    if(this->tamanhojan==0)
    {
        double *event;
        vector < double > vetEvents;

        for(int i=0;i<this->nos.size();i++)
        {
            vetEvents.clear();
            for(int j=K;j<(this->ME[i].size()-1)-K;j++)
            {
                bool e_max=true;
                for(int k=j-K+1;k<j+K;k++)
                {
                    if(this->ME[i][k]>this->ME[i][j])
                    {
                        e_max=false;
                        break;
                    }

                }
                if(e_max && (this->ME[i][j+K]+h)<this->ME[i][j] && (this->ME[i][j-K]+h)<this->ME[i][j])
                    vetEvents.push_back(j);
            }
            this->matEvents.push_back(vetEvents);
        }
    }
    else
    {
        double *event;
        vector < double > vetEvents;
        this->matEvents.clear();

        for(int i=0;i<this->nos.size();i++)
        {
            vetEvents.clear();
            for(int j=this->vInicio+K;j<(this->vInicio+this->tamanhojan)-K;j++)
            {
                bool e_max=true;
                for(int k=j-K+1;k<j+K;k++)
                {
                    if(this->ME[i][k]>this->ME[i][j])
                    {
                        e_max=false;
                        break;
                    }

                }
                if(e_max && (this->ME[i][j+K]+h)<this->ME[i][j] && (this->ME[i][j-K]+h)<this->ME[i][j])
                    vetEvents.push_back(j);
            }
            this->matEvents.push_back(vetEvents);
        }
    }
}

double cRede::tau_ij(int x,int y,int i,int j)
{
    double TAU,ax,bx,ay,by;
    ax=this->matEvents[x][i+1]-this->matEvents[x][i];
    bx=this->matEvents[x][i]-this->matEvents[x][i-1];
    ay=this->matEvents[y][j+1]-this->matEvents[y][j];
    by=this->matEvents[y][j]-this->matEvents[y][j-1];

    TAU=min(min(ax,bx),min(ay,by))/2;

    return this->tau; //min(TAU,this->tau);
}

double cRede::c_xy(int x, int y)
{
    double Jxy=0;
    int tamx,tamy;

    tamx=this->matEvents[x].size();
    tamy=this->matEvents[y].size();
    int ult_j=0;

    for(int i=0;i<tamx;i++)
    {
        for(int j=ult_j;j<tamy;j++)
        {
            int J=this->matEvents[x][i]-this->matEvents[y][j];
            if(J<=this->tau && J >0)
            {
                Jxy++;
                ult_j=j;
            }
            else if(J==0)
            {
                Jxy+=0.5;
                ult_j=j;
            }
            else if(J<this->tau)
            {
                ult_j=j;
                break;
            }
        }
    }
    return Jxy;
}

double cRede::Q_xy(int x, int y)
{
    double tamx,tamy;
    tamx=this->matEvents[x].size();
    tamy=this->matEvents[y].size();

    double Q;

    if(tamx==0 || tamy==0)
        Q=0;
    else
        Q=(c_xy(x,y)+c_xy(y,x))/sqrt(tamx*tamy);

    return Q;
}

double cRede::q_xy(int x, int y)
{
    double tamx,tamy;
    tamx=this->matEvents[x].size();
    tamy=this->matEvents[y].size();

    double q;

    if(tamx==0 || tamy==0)
        q=0;
    else
        q=(c_xy(y,x)-c_xy(x,y))/sqrt(tamx*tamy);

    return q;

}

// MotifsSynchronization

void cRede::gera_motifs2()
{
    int cteFinal;
    cteFinal=(2*this->lag+1);

    for(int i=0;i<this->nos.size();i++)
    {
        this->Vmotif.clear();
        for(int j=0;j<(this->ME[i].size()-1)-cteFinal;j++)
        {
            if(this->ME[i][j]>this->ME[i][j+lag] && this->ME[i][j+lag]>this->ME[i][j+2*lag])  // Motif 1
            { this->Vmotif.push_back(1);}
            else if(this->ME[i][j]>this->ME[i][j+lag] && this->ME[i][j+lag]<this->ME[i][j+2*lag])  // Motif 2
            { this->Vmotif.push_back(2);}
            else if(this->ME[i][j]<this->ME[i][j+lag] && this->ME[i][j+lag]>this->ME[i][j+2*lag])  // Motif 3
            { this->Vmotif.push_back(3);}
            else if(this->ME[i][j]<this->ME[i][j+lag] && this->ME[i][j+lag]<this->ME[i][j+2*lag])  // Motif 4
            { this->Vmotif.push_back(4);}
            else if(this->ME[i][j]+ME[i][j+lag]+ME[i][j+2*lag]==0)    // Null motif
            {this->Vmotif.push_back(0);}
            else // Motif 5
            { this->Vmotif.push_back(5);}

        }
        this->matMotifs.push_back(this->Vmotif);
    }
}

int cRede::c2_xy(int x, int y)
{
    int tam,n,M1,M2,tau_est=-1;
    double soma=0;
    this->Jxy=0;

    if(this->tamanhojan==0)
    {

        tam=this->getMotifs_size()-this->tau;

        for(n=0;n<this->tau+1;n++)
        {
            soma=0;
            for(int i=0;i<tam;i++)
            {
                M1=this->matMotifs[x][i];
                M2=this->matMotifs[y][i+n];
                if(M1==M2 && M1!=0)
                {
                    soma++;
                }
            }
            if(soma>=this->Jxy)
            {
                this->Jxy=soma;
                tau_est=n;
            }
        }
    }
    else
    {
        tam=this->tamanhojan;
        for(n=0;n<this->tau+1;n++)
        {
            soma=0;
            for(int i=this->vInicio;i<(this->vInicio+tam);i++)
            {
                M1=this->matMotifs[x][i];
                M2=this->matMotifs[y][i+n];
                if(M1==M2 && M1!=0)
                {
                    soma++;
                }
            }
            if(soma>=this->Jxy)
            {
                this->Jxy=soma;
                tau_est=n;
            }
        }
    }
    return tau_est;
}

int cRede::c2_yx(int x, int y)
{
    int tam,n,M1,M2,tau_est=-1;
    double soma=0;
    this->Jyx=0;

    if(this->tamanhojan==0)
    {

        tam=this->getMotifs_size()-this->tau;

        for(n=0;n<this->tau+1;n++)
        {
            soma=0;
            for(int i=0;i<tam;i++)
            {
                M1=this->matMotifs[x][i];
                M2=this->matMotifs[y][i+n];
                if(M1==M2 && M1!=0)
                {
                    soma++;
                }
            }
            if(soma>=this->Jyx)
            {
                this->Jyx=soma;
                tau_est=n;
            }
        }
    }
    else
    {
        tam=this->tamanhojan;

        for(n=0;n<this->tau+1;n++)
        {
            soma=0;
            for(int i=this->vInicio;i<(this->vInicio+tam);i++)
            {
                M1=this->matMotifs[x][i];
                M2=this->matMotifs[y][i+n];
                if(M1==M2  && M1!=0)
                {
                    soma++;
                }
            }
            if(soma>=this->Jyx)
            {
                this->Jyx=soma;
                tau_est=n;
            }
        }
    }
    return tau_est;
}

double cRede::Q2_xy(int x, int y)
{
    double tam,qxy,qyx,Q;

    qxy=this->Jxy;
    qyx=this->Jyx;

    if(this->tamanhojan==0)
        tam=this->getMotifs_size()-this->tau;
    else
        tam=this->tamanhojan;

    Q=max(qxy,qyx)/tam;

    return Q;
}

double cRede::q2_xy(int x, int y)
{
    double d,dxy,dyx,q,tam;

    dxy=this->Jxy;
    dyx=this->Jyx;


    if(dxy==dyx)
    {
        q=0;
    }
    else
    {
        d=max(dxy,dyx);

        if(d==dxy)
            q=1;
        else
            q=-1;
    }

    return q;
}

// M�dia

double cRede::media(vector < vector <double> > dados,int j)
{
    double m,s;
    int n,sizeme;
    sizeme=dados[0].size();
    m=0;
    s=0;
    if(tamanhojan==0 || sizeme<dados.size())
    {
        for(n=0;n<sizeme;n++)
        {
            s+=dados[j][n];
        }
        m=s/n;
    }
    else
    {
        sizeme=this->tamanhojan;
        for(n=this->vInicio;n<(this->vInicio+sizeme);n++)
        {
            s+=dados[j][n];
        }
        m=s/sizeme;
    }

    return m;
}

// Covari�ncia

double cRede::cov(vector < vector <double> > dados,int j,int k)
{
    double s,c,m1,m2;
    int n,sizeme;
    sizeme=dados[0].size();
    s=0;
    c=0;
    m1=this->media(dados,j);
    m2=this->media(dados,k);

    if(tamanhojan==0 || sizeme<dados.size())
    {
        for(n=0;n<sizeme;n++)
        {
            c=(dados[j][n]-m1)*(dados[k][n]- m2);
            s+=c;
        }
    }
    else
    {
        sizeme=this->tamanhojan;
        for(n=this->vInicio;n<(this->vInicio+sizeme);n++)
        {
            c=(dados[j][n]-m1)*(dados[k][n]- m2);
            s+=c;
        }
    }

    return s/sizeme;
}

// Vari�ncia

double cRede::var(vector < vector <double> > dados,int j)
{
    double s,v,m1;
    int n,sizeme;
    sizeme=dados[0].size();
    s=0;
    v=0;
    m1=this->media(dados,j);

    if(tamanhojan==0 || sizeme<dados.size())
    {
        for(n=0;n<sizeme;n++)
        {
            v=(dados[j][n]-m1)*(dados[j][n]-m1);
            s+=v;
        }
    }
    else
    {
        sizeme=this->tamanhojan;
        for(n=this->vInicio;n<(this->vInicio+sizeme);n++)
        {
            v=(dados[j][n]-m1)*(dados[j][n]-m1);
            s+=v;
        }
    }


    return s/sizeme;
}

// Vizinhos

int cRede::Vizinho(vector < vector <double> >  dados,int k,int i){
    vector <int> V;
    for(int j=0;j<this->getNumDeEnt();j++){
        if(dados[i][j]>=1){
            V.push_back(j);
        }
    }
    return V[k];
}

// Numero de arestas entre os vizinhos

int cRede::n_ar(int j)
{
    int nj=0;
    if(this->G[j]!=1 || this->G[j]!=0)
    {
        for(int i=0;i<this->G[j];i++)
        {
            for(int k=0;k<this->G[this->Vizinho(this->MAdj,i,j)];k++)
            {
                for(int n=0;n<this->G[j];n++)
                {
                    if(this->Vizinho(this->MAdj,k,this->Vizinho(this->MAdj,i,j))==this->Vizinho(this->MAdj,n,j))
                    {
                        nj+=1;
                    }
                }
            }
        }
    }

    else {
        nj=0;
    }
    return nj;
}

// Coeficientes de aglomera��o dos vertices

double cRede::CAv(int i)
{



    // return 1;   // provisorio RETIRAR



    double ci;
    if(this->G[i]==1 || this->G[i]==0)
        ci=0;
    else
        ci=(2*(double)this->n_ar(i)/2)/(double)(this->G[i]*(this->G[i]-1));

    return ci;
}

//...

void cRede::soma_matriz(vector<vector<double> > *m1,vector<vector<double> > *m2)
{
    for(int i=0;i<getNumDeEnt();i++)
    {
        for(int j=0;j<getNumDeEnt();j++)
        {
            m1->at(i).at(j)+=m2->at(i).at(j);
        }
    }
}

void cRede::carregaListaAquivos(vector <QString> arquivos)
{
    this->listaArquivos.clear();
    for(int i=0;i<this->nos.size();i++)
        delete this->nos[i];
    this->nos.clear();

    for(int i=0; i<arquivos.size();i++)
    {
        string nome;
        cNo *aux = new cNo(nome,i);

        nome=arquivos[i].toStdString();
        this->listaArquivos.push_back(nome);
        this->nos.push_back(aux); //identifica os nos
    }
}

void cRede::carrega_arq()
{
    double valor=0;
    this->ME.clear();

    for(int i=0;i<this->getNumDeEnt();i++)
    {
        ifstream leitor;
        VE.clear();
        leitor.open(this->listaArquivos[i].c_str());
        if (leitor.is_open())
        {
            while (!leitor.fail())
            {
                leitor >> valor;
                this->VE.push_back(valor);

            }
        }
        this->ME.push_back(VE);
        leitor.close();
    }

}

void cRede::carrega_arq2(string nome_arq)
{

    this->zera();

    for(int i=0;i<this->nos.size();i++)
        delete this->nos[i];
    this->nos.clear();

    int i=0;
    int j=1;
    this->ME.clear();
    this->VE.clear();


    string texto;
    bool ok;

    ifstream leitor2;

    leitor2.open(nome_arq.c_str());
    if (leitor2.is_open())
    {
        while (!leitor2.fail())
        {

            leitor2>>texto;
            QString text = QString::fromStdString(texto);
            int value = text.toDouble(&ok);//.toInt(&ok,10); //Convers�o para verificar se o valor � numerico
            if (j<i)
            {
                j+=1;
                this->ME.push_back(VE);
                VE.clear();
            }
            if (!ok) //se n�o aconteceu a convers�o pra inteiro � pq � uma string, logo
            {
                i+=1;
                cNo *aux = new cNo(text.toStdString(),i);
                this->nos.push_back(aux);
            }
            else
            {
                double valor=text.toDouble(&ok);
                this->VE.push_back(valor);
            }

        }
        VE.pop_back();
        ME.push_back(VE);
    }
    leitor2.close();

    //CARREGA AS POSI�OES DO ELETRODOS//

    i=0;
    j=1;
    ifstream leitor3;
    vector < double > vaux;
    leitor3.open("Location19.dat");
    if (leitor3.is_open())
    {
        while (!leitor3.fail())
        {

            leitor3>>texto;
            QString text = QString::fromStdString(texto);
            int value = text.toDouble(&ok); //Convers�o para verificar se o valor � numerico
            if (j<i)
            {
                j+=1;
                this->coordelet.push_back(vaux);
                vaux.clear();
            }
            if (!ok) //se n�o aconteceu a convers�o pra inteiro � pq � uma string, logo
            {
                if(texto==this->nos[i]->id)
                    i+=1;
            }
            else
            {
                double valor=text.toDouble(&ok);
                vaux.push_back(valor);
            }

        }
        vaux.pop_back();
        this->coordelet.push_back(vaux);
    }
    leitor3.close();

}

void cRede::loadASCII(QString nome_arq)
{

    this->zera();

    for(int i=0;i<this->nos.size();i++)
        delete this->nos[i];

    this->nos.clear();

    int i=0,iA1=0,iA2=0;
    this->ME.clear();
    this->VE.clear();

    vector <vector <double> > MEt;

    string texto, a1="A1", a2="A2";
    bool ok;

    ifstream leitor2;

    leitor2.open(nome_arq.toLocal8Bit());


    if (leitor2.is_open())
    {
        // read header
        string line;
        getline(leitor2,line);
        QString qLine(line.c_str());
        QStringList data;
        data=qLine.split('\t');
        for(int i=0;i<data.size();i++)
        {
            QString text = QString::fromLatin1(data[i].toStdString().c_str());
            cNo *aux = new cNo(text.toStdString(),i);
            this->nos.push_back(aux);
        }
        // read data
        getline(leitor2,line);
        while (line.size()>2)
        {
            QString qLine(line.c_str());
            QStringList data;
            data=qLine.split('\t');
            for(int j=0;j<data.size();j++)
            {
                double valor=data[j].toDouble(&ok);
                if(ok)
                    this->VE.push_back(valor);
                else
                    this->VE.push_back(0);
            }
            MEt.push_back(VE);
            VE.clear();
            getline(leitor2,line);
        }
    }
    leitor2.close();


    vector <double> vetnum;
    vetnum.assign(MEt.size(),0);

    this->ME.assign(MEt[0].size(),vetnum);

    for(int i=0;i<MEt[0].size();i++)
    {
        for(int j=0;j<MEt.size()-1;j++)
        {
            this->ME[i][j]=MEt[j][i];
        }
    }


    MEt.clear();

 }

void cRede::shufData()
{

    int num=getNumDeEnt();
    int mSize=this->getME_size();
    double aux;

    for(int i=0;i<num;i++)
    {
        for(int j=0;j<mSize;j++)
        {
            aux=this->ME[i][j];
            int k=(double)rand()/RAND_MAX*(mSize-1);
            this->ME[i][j]=this->ME[i][k];
            this->ME[i][k]=aux;
        }
    }
}


//Gets

double cRede::getmDxy(int i, int j)
{
    return this->matDxy[i][j];
}

double cRede::getCmMedio()
{
    return this->cmMedio;
}

double cRede::getPearson(int i,int j)
{
    return this->matPearson[i][j];
}

char cRede::getMotif(int i, int j)
{
    return this->matMotifs[i][j];
}

double cRede::getAdj(int i,int j)
{
    return this->MAdj[i][j];
}

double cRede::getViz(int i,int j)
{
    return this->MViz[i][j];
}

double cRede::getGrauMedio()
{
    return this->grauMedio;
}

double cRede::getCaMedio()
{
    return this->caMedio;
}

int cRede::getG(int i)
{
    return this->G[i];
}

int cRede::getNumDeEnt()
{
    return this->nos.size();
}

void cRede::zera()
{
    this->caMedio=0;
    this->grauMedio=0;
    this->MAdj.clear();
    this->matPearson.clear();
    this->MViz.clear();
    this->matDxy.clear();
    this->thresold=0;
    this->cmMedio=0;
    this->G.clear();
    this->matMotifs.clear();
    this->fMotif1.clear();
    this->fMotif2.clear();
    this->fMotif3.clear();
    this->fMotif4.clear();
    this->fMotif5.clear();
    this->fMotif6.clear();
    this->fMotif7.clear();
    this->tamanhojan=0;
    this->eletX_pxx=0;
    this->eletX_pxy=0;
    this->eletX_pxyy=0;
    this->eletY_pxy=0;
    this->eletY_pxyy=0;
    this->MAdj_tvg.clear();
    this->matDxy_tvg.clear();
    this->G_tvg.clear();
    this->Gin_tvg.clear();
    this->Gout_tvg.clear();
    this->grauMedio_tvg.clear();
    this->grauMedioIn_tvg.clear();
    this->grauMedioOut_tvg.clear();
    this->caMedio_tvg.clear();
    this->cmMedio_tvg.clear();
    this->matQxy_tvg.clear();
    this->MViz_tvg.clear();
    this->matEvents.clear();
    this->tamanhojan=0;
    this->matQxy.clear();
    this->K=0;
    this->h=0;
    this->matDig.clear();
    this->matDig_tvg.clear();
    this->tau=0;
    this->lag=0;
    this->dmax=0;
    this->dmin=0;
    this->vInicio=0;
    this->Jxy=0;
    this->Jyx=0;
    this->delta=0;
    this->max_arest=0;
    this->arestas_tvg.clear();
    this->tamanho=0;
    this->Narestas_tvg.clear();
    this->dpG_tvg.clear();
    this->dpG=0;
    this->dpGin_tvg.clear();
    this->dpGout_tvg.clear();
    this->max_arest=0;
}
