#include "cno.h"


cNo::cNo(string id, int i)
{
    this->id=id;
    this->num=i;
    this->posX=(double)rand()/(double)RAND_MAX;
    this->posY=(double)rand()/(double)RAND_MAX;
}
