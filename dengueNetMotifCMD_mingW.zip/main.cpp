#include <iostream>
#include "crede.h"
#include <vector>
using namespace std;

void TVG_indices_triggered();
void calcRea();

class cRede rede;
vector < vector <double> > snet;
bool shuffled;
bool makenet;
int arestaMAX;
double dpA; //desvio padrao dos pesos das arestas
double Amedia; //peso medio das arestas
QString vetor2intervals(vector <int> vt);


int main(int *argv,char **argc)
{
    QString nomeArquivo(argc[1]);
    double th=atof(argc[2]);
    int jan=atoi(argc[3]);
    int lag=atoi(argc[4]);
    int tau=atoi(argc[5]);
    int ti=atoi(argc[6]);
    int tf=atoi(argc[7]);
    int sh=atoi(argc[8]);
    int printLog=atoi(argc[9]);
    double minV = atof(argc[10]);

    rede.fileName=nomeArquivo;
    cout << "Carregando dados..."<<endl;
    rede.loadASCII(nomeArquivo);

    if(tf>rede.getME_size())
    {
        cout << "Aviso!: Tamanho dos dados menor do que o tempo informado "<<rede.getME_size()<<"/"<<tf<<endl;
        tf=rede.getME_size();
    }
    if(sh==0)
        shuffled=false;
    else
    {
        shuffled=true;
        rede.shufData();
    }

    cout << "calculando tvg..."<<endl;

    rede.calc_tudo9(th,jan,lag,tau,tf,ti,minV, shuffled,printLog==1);

    cout << "calculando Hubs..."<<endl;
    TVG_indices_triggered();

    cout << "calculando Rea..."<<endl;
    calcRea();


    return 0;
}

void TVG_indices_triggered()
{
    vector <double> hubs,hubsIn,hubsOut;
    hubs.assign(rede.getNumDeEnt(),0);
    hubsIn.assign(rede.getNumDeEnt(),0);
    hubsOut.assign(rede.getNumDeEnt(),0);
    ofstream TVGi,Hubs;
    QString nameTvg,nameHub;
    nameTvg=rede.fileName+"_tvg.txt";
    nameHub=rede.fileName+"_hub.txt";

    TVGi.open(nameTvg.toLocal8Bit());
    Hubs.open(nameHub.toLocal8Bit());

    TVGi<<"Net\t<k>\t<c>\tT\tTauMed"<<endl;
    Hubs<<"No\tnormal\tin\tout\tPnormal\tPin\tPout"<<endl;
    Hubs<<endl;

    double somahub=0,somahubIn=0,somahubOut=0;

    for(int i=0;i<rede.grauMedio_tvg.size();i++)
    {
        for(int j=0;j<rede.G_tvg[i].size();j++)
        {
            if((double)rede.G_tvg[i][j]>=rede.grauMedio_tvg[i]+2*rede.dpG_tvg[i] && (double)rede.G_tvg[i][j]!=0)
            {
                hubs[j]++;
                somahub++;
            }
            if((double)rede.Gin_tvg[i][j]>=rede.grauMedioIn_tvg[i]+2*rede.dpGin_tvg[i] && (double)rede.Gin_tvg[i][j]!=0)
            {
                hubsIn[j]++;
                somahubIn++;
            }
            if((double)rede.Gout_tvg[i][j]>=rede.grauMedioOut_tvg[i]+2*rede.dpGout_tvg[i] && (double)rede.Gout_tvg[i][j]!=0)
            {
                hubsOut[j]++;
                somahubOut++;
            }
            TVGi<<i+1<<"\t"<<rede.grauMedio_tvg[i]<<"\t"<<rede.caMedio_tvg[i]<<"\t"<<rede.Narestas_tvg[i]<<"\t"<<rede.tauMed_tvg[i]<<endl;
        }
    }
    TVGi.close();
    for(int j=0;j<rede.getNumDeEnt();j++)
    {
        Hubs<<rede.nos[j]->id<<"\t"<<hubs[j]<<"\t"<<hubsIn[j]<<"\t"<<hubsOut[j]<<
              "\t"<<hubs[j]/somahub<<"\t"<<hubsIn[j]/somahubIn<<"\t"<<hubsOut[j]/somahubOut<<endl;
    }
    Hubs.close();
}

void calcRea()
{
    vector <double> vnum,Gp,GpSN,GSN;
    double GpMedio,tSN=0;
    int aux=0;
    int num=rede.getNumDeEnt();
    arestaMAX=0;
    rede.tamanho=0;
    vnum.assign(num,0);
    snet.assign(num,vnum);

    Gp.assign(num,0); //grau ponderado
    GpSN.assign(num,0); //grau ponderado da reah
    GSN.assign(num,0); //grau da reah

    double somaA=0,somaA2=0;
    double nA;



    for(int i=0;i<rede.nos.size();i++)
    {
        for(int j=0;j<rede.nos.size();j++)
        {

            arestaMAX=max(arestaMAX,aux);
            aux=rede.matrizC[i][j];
            rede.MAdj[i][j]=aux;

            nA++;  //numero de arestas
            somaA+=aux; //soma dos pesos
            somaA2+=aux*aux; //soma dos pesos^2
        }
    }

    double somaA2medio=somaA*somaA/nA; //peso quadratico medio
    Amedia=somaA/nA; //peso medio das arestas
    dpA=sqrt((somaA2-somaA2medio)/(nA-1)); //desvio dos pesos das arestas

    // Graus da rede
    int grau,graup,grauSN,graupSN;

    for(int i=0;i<num;i++)              // calcula a reaHub
    {
        grau=0,graup=0,grauSN=0,graupSN=0;
        for(int j=0;j<num;j++)
        {
            if(rede.MAdj[i][j]>=1)
            {
                graup+=rede.MAdj[i][j];
                grau+=1;
                rede.tamanho++;
                if(rede.MAdj[i][j]>=Amedia+2.0*dpA)
                {
                    snet[i][j]=rede.MAdj[i][j];
                    graupSN+=rede.MAdj[i][j];
                    grauSN+=1;
                    tSN++;
                }
            }
        }
        rede.G[i]=grau;
        Gp[i]=graup;

        GSN[i]=grauSN;
        GpSN[i]=graupSN;
    }

    double s=0,Gmedio=0,skp=0,GmedioSN=0,skpSN=0;
    for(int i=0;i<num;i++)              // calcula indices medios da rea
    {
        Gmedio+=rede.G[i];
        //s+=rede.CAv(i);
        skp+=Gp[i];

        GmedioSN+=GSN[i];
        skpSN+=GpSN[i];
    }
    rede.grauMedio=Gmedio/num;      // Grau medio da rede
    rede.caMedio=-1; //s/num;             // Coefifiente de aglomeracao medio
    GpMedio=skp/num;                //grau ponderado medio

    //SAIDA DOS INDICES

    ofstream Cneti,MC,Reah,iReah,ReaD,Tvg_Gephi;
    QString nameCnet,nameMC,nameReah,nameiReah,nameReaD,nameTVG;

    nameCnet=rede.fileName+"_iREA.txt";
    nameMC=rede.fileName+"_REA.txt";
    nameReah=rede.fileName+"_REAh.txt";
    nameiReah=rede.fileName+"_iREAh.txt";
    nameReaD=rede.fileName+"_REAd.txt";
    nameTVG=rede.fileName+"_TVG_Gephi.txt";


    Cneti.open(nameCnet.toLocal8Bit());
    MC.open(nameMC.toLocal8Bit());
    Reah.open(nameReah.toLocal8Bit());
    iReah.open(nameiReah.toLocal8Bit());
    ReaD.open(nameReaD.toLocal8Bit());
    Tvg_Gephi.open(nameTVG.toLocal8Bit());

    Cneti<<"T\t<k>\t<c>\t<kp>"<<endl;
    Cneti<<rede.tamanho<<"\t"<<rede.grauMedio<<"\t"<<rede.caMedio<<"\t"<<GpMedio<<endl;
    Cneti<<endl;

    iReah<<"T\t<k>\t<c>\t<kp>"<<endl;
    iReah<<tSN<<"\t"<<GmedioSN/num<<"\t"<<0<<"\t"<<skpSN/num<<endl;
    iReah<<endl;

    Cneti<<"No\tki\tci\tkpi"<<endl;
    iReah<<"No\tki\tci\tkpi"<<endl;
    Tvg_Gephi<<"Source\tTarget\tInter"<<endl;
    MC << "Source\tTarget\tWeight\tType"<<endl;
    Reah << "Source\tTarget\tWeight\tType"<<endl;
    ReaD << "Source\tTarget\tWeight\ttau"<<endl;
    for(int i=0;i<num;i++)
    {
        double ca=-1;//rede.CAv(i);
        Cneti<<rede.nos[i]->id<<"\t"<<rede.G[i]<<"\t"<<ca<<"\t"<<Gp[i]<<endl;
        iReah<<rede.nos[i]->id<<"\t"<<GSN[i]<<"\t"<<0<<"\t"<<GpSN[i]<<endl;
        for(int j=0;j<num;j++)
        {
            string source=rede.nos[i]->id;
            string target=rede.nos[j]->id;
            if(rede.matrizC[i][j]!=0 && i>j)
            {
                MC <<source<<"\t"<<target<<"\t"<<rede.matrizC[i][j]<<"\t"<<"Undirected"<<endl;
                if(snet[i][j]!=0)
                    Reah <<source<<"\t"<<target<<"\t"<<snet[i][j]<<"\t"<<"Undirected"<<endl;
            }
            if(rede.matrizCD[i][j]!=0)
            {
                ReaD <<source<<"\t"<<target<<"\t"<<rede.matrizCD[i][j]<<"\t"<<(double)rede.matTau[i][j]/rede.matrizCD[i][j]<<endl;
                QString sInterval;
                sInterval=vetor2intervals(rede.matTvg[i][j]);
                Tvg_Gephi<<source<<"\t"<<target<<"\t"<<sInterval.toStdString()<<endl;
            }
        }
    }
    Cneti.close();
    MC.close();
    iReah.close();
    Reah.close();
    ReaD.close();
    Tvg_Gephi.close();
}

QString vetor2intervals(vector <int> vt)
{
    QString interv;
    int i;
    interv="<["+QString::number(vt[0]);
    for(i=1;i<vt.size();i++)
    {
        if(vt[i]-vt[i-1]>1)
            interv+=","+QString::number(vt[i-1])+"];["+QString::number(vt[i]);
    }
    interv+=","+QString::number(vt[i-1])+"]>";
    return interv;
}
